<?php
require_once '../config/config.php';
require_once '../models/Property.php';
require_once '../models/User.php';

// Include Header
include 'includes/header.php';

// Fetch Tenant Data
$user_id = $_SESSION['user_id'];
// We need a way to check if tenant is assigned to a property.
// Assuming a 'rentals' table exists or properties table has 'tenant_id'.
// For now, let's assume we will create a rentals table later.
// Let's just mock active rental for dashboard structure.
$active_rental = null; // Placeholder

?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="mb-1 fw-bold">Welcome back, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h4>
            <p class="text-muted small mb-0">Manage your rental and payments.</p>
        </div>
    </div>

    <!-- Stats Grid -->
    <div class="row g-4 mb-5">
        <div class="col-md-4">
            <div class="stats-card">
                <div class="stats-icon icon-brown">
                    <i class="bi bi-house-door-fill"></i>
                </div>
                <div class="stats-info">
                    <h6>Current Rental</h6>
                    <h3><?php echo $active_rental ? 'Active' : 'None'; ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stats-card">
                <div class="stats-icon icon-orange">
                    <i class="bi bi-calendar-check-fill"></i>
                </div>
                <div class="stats-info">
                    <h6>Next Due Date</h6>
                    <h3>--</h3>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stats-card">
                <div class="stats-icon icon-green">
                    <i class="bi bi-wallet2"></i>
                </div>
                <div class="stats-info">
                    <h6>Last Payment</h6>
                    <h3>--</h3>
                </div>
            </div>
        </div>
    </div>

    <?php if(!$active_rental): ?>
    <div class="alert alert-info border-0 shadow-sm d-flex align-items-center" role="alert">
        <i class="bi bi-info-circle-fill fs-4 me-3 text-info"></i>
        <div>
            <h6 class="fw-bold mb-1">No Active Rental Found</h6>
            <p class="mb-0 small">You are not currently linked to any property. Ask your landlord/dealer to add you to their property using your email: <strong><?php echo $_SESSION['user_email'] ?? 'your email'; ?></strong></p>
        </div>
    </div>
    <?php endif; ?>

    <!-- Recent Payments Placeholder -->
    <div class="card border-0 shadow-sm rounded-3 mb-4">
        <div class="card-header bg-white border-0 py-3 d-flex justify-content-between align-items-center">
            <h5 class="mb-0 fw-bold">Recent Payments</h5>
            <a href="payments.php" class="btn btn-sm btn-outline-primary">View History</a>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light text-muted small text-uppercase">
                        <tr>
                            <th class="ps-4">Month</th>
                            <th>Amount</th>
                            <th>Proof</th>
                            <th>Status</th>
                            <th>Date Uploaded</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="5" class="text-center py-5">
                                <div class="text-muted mb-3">
                                    <i class="bi bi-receipt fs-1 opacity-25"></i>
                                </div>
                                <h5 class="fw-bold text-muted">No Payment Records</h5>
                                <p class="text-muted small">Your payment history will appear here once you start paying rent.</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>